import React from 'react'

function Hello() {
  return (
    <div>Hello</div>
  )
}

export default Hello