import React from 'react'

export default function Messages() {
  return (
    <FrontLayout>

    <div>Messages</div>
    </FrontLayout>
  )
}
