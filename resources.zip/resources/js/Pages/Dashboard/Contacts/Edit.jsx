import DashboardLayout from '@/Layouts/DashboardLayout'
import React from 'react';

export default function Edit({auth,webpage,page_id='',page_subid='',page_title ='',page_subtitle ='',pays}) {
  return (
    <DashboardLayout auth={auth} page_id={page_id} page_subid={page_subid}>
      
    </DashboardLayout>
  )
}
