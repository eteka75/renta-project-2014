const HTTP_FRONTEND_HOME='/';
//const HTTP_FRONTEND_HOME="http://127.0.0.1:8000/";
//const HTTP_FRONTEND_HOME="https://rentalcarservices-benin.com/";
export { HTTP_FRONTEND_HOME };
