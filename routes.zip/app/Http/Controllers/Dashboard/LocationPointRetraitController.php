<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\LocationPointRetrait;
use Illuminate\Http\Request;

class LocationPointRetraitController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(LocationPointRetrait $locationPointRetrait)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(LocationPointRetrait $locationPointRetrait)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, LocationPointRetrait $locationPointRetrait)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(LocationPointRetrait $locationPointRetrait)
    {
        //
    }
}
